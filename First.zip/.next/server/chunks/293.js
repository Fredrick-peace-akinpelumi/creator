"use strict";
exports.id = 293;
exports.ids = [293];
exports.modules = {

/***/ 891:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/loading.6bddc374.gif","height":360,"width":480});

/***/ }),

/***/ 5377:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Register__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3372);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Register__WEBPACK_IMPORTED_MODULE_2__]);
_Register__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Index = ()=>{
    const [email, setemail] = useState();
    const [message, setmessage] = useState("");
    const [state, setstate] = useState(true);
    const [password, setpassword] = useState();
    const login = ()=>{};
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: state == true ? /*#__PURE__*/ _jsx("div", {
            className: "shadow mt-5 p-5 col-lg-4",
            children: /*#__PURE__*/ _jsxs("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ _jsx("h1", {
                        children: "Welcome back"
                    }),
                    message !== "" ? /*#__PURE__*/ _jsx("b", {
                        className: "alert alert-danger",
                        children: message
                    }) : "",
                    /*#__PURE__*/ _jsx("input", {
                        className: "form-control mb-3 p-3 shadow-sm border-0",
                        onChange: (e)=>setemail(e.target.value),
                        value: email,
                        placeholder: "Example@gmail.com",
                        type: "text"
                    }),
                    /*#__PURE__*/ _jsx("input", {
                        className: "form-control mb-3 p-3 shadow-sm border-0",
                        onChange: (e)=>setpassword(e.target.value),
                        value: password,
                        placeholder: "Password",
                        type: "text"
                    }),
                    /*#__PURE__*/ _jsx("button", {
                        className: "btn",
                        onClick: ()=>setstate(!state),
                        children: "Create Account"
                    }),
                    /*#__PURE__*/ _jsx("button", {
                        className: "btn btn-primary",
                        onClick: ()=>login(),
                        children: "Login"
                    })
                ]
            })
        }) : /*#__PURE__*/ _jsx(Register, {})
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Index)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9648);
/* harmony import */ var _public_loading_gif__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(891);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Login__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5377);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_4__, _Login__WEBPACK_IMPORTED_MODULE_7__]);
([axios__WEBPACK_IMPORTED_MODULE_4__, _Login__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Register = ()=>{
    const [email, setemail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [password, setpassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loginemail, setloginemail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [loginpassword, setloginpassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [confirmPass, setconfirmPass] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [state, setstate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [message, setmessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loading, setloading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [usersArr, setusersArr] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const register = ()=>{
        if (!email || !password || !confirmPass) return setmessage("Fill all fields");
        let users = {
            email,
            password,
            confirmPass
        };
        setusersArr((prev)=>[
                ...prev,
                users
            ]);
        if (password !== confirmPass) {
            setmessage("Confirm password must be same as password");
        } else {
            setloading(true);
            axios__WEBPACK_IMPORTED_MODULE_4__["default"].post("http://localhost:4000/signup", users).then((res)=>{
                console.log(res);
                if (res.data.message && !res.data.status) {
                    setmessage(res.data.message);
                } else {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/Form");
                }
                setloading(false);
            }).catch((err)=>{
                if (err) {
                    setmessage(err.message);
                } else {
                    next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/Form");
                }
            });
            console.log(usersArr);
        }
    };
    const login = ()=>{
        if (!loginemail || !loginpassword) return setmessage("Fill all fields");
        let loginUser = {
            loginemail,
            loginpassword
        };
        setloading(true);
        axios__WEBPACK_IMPORTED_MODULE_4__["default"].post("http://localhost:4000/login", loginUser).then((res)=>{
            console.log(res);
            if (res.data.message) {
                setmessage(res.data.message);
                next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/Form");
            }
            setloading(false);
        }).catch((err)=>{
            if (err) {
                setmessage(err.message);
            } else {
                next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/Form");
            }
        });
        setmessage("");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-lg-flex container",
                children: [
                    state == true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "shadow mt-5 p-5 col-lg-",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    children: "Register now"
                                }),
                                message !== "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                    className: "alert alert-danger",
                                    children: message
                                }) : "",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "form-control mb-3 p-3 shadow-sm border-0",
                                    onChange: (e)=>setemail(e.target.value),
                                    value: email,
                                    placeholder: "Example@gmail.com",
                                    type: "text"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "form-control mb-3 p-3 shadow-sm border-0",
                                    onChange: (e)=>setpassword(e.target.value),
                                    value: password,
                                    placeholder: "Password",
                                    type: "text"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "form-control mb-3 p-3 shadow-sm border-0",
                                    onChange: (e)=>setconfirmPass(e.target.value),
                                    value: confirmPass,
                                    placeholder: "Confirm password",
                                    type: "text"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn border-0",
                                    onClick: ()=>setstate(!state),
                                    children: "Login here"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn btn-primary",
                                    onClick: ()=>register(),
                                    children: "Create cv"
                                })
                            ]
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "shadow mt-5 p-5 ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    children: "Welcome back"
                                }),
                                message !== "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                    className: "alert alert-danger",
                                    children: message
                                }) : "",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "form-control mb-3 p-3 shadow-sm border-0",
                                    onChange: (e)=>setloginemail(e.target.value),
                                    value: loginemail,
                                    placeholder: "Example@gmail.com",
                                    type: "text"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "form-control mb-3 p-3 shadow-sm border-0",
                                    onChange: (e)=>setloginpassword(e.target.value),
                                    value: loginpassword,
                                    placeholder: "Password",
                                    type: "text"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn border-0",
                                    onClick: ()=>setstate(!state),
                                    children: "Create Account"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "btn btn-primary",
                                    onClick: ()=>login(),
                                    children: "Login"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-lg-6 mt-5 p-5",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                    className: "text-primary",
                                    children: "Dev CvCreator "
                                }),
                                "is here for young and great developers looking for jobs, we are interested in helping you create a wonderful Curriculum vitae template to search for the job of your choice, Signup to create your CV"
                            ]
                        })
                    })
                ]
            }),
            loading == true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gif ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                    alt: "",
                    src: _public_loading_gif__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                    width: 1000,
                    height: 1000
                })
            }) : ""
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Register);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;