import React, {useState} from 'react'
import Link from 'next/link'
import Router, { useRouter } from 'next/router'
import axios from 'axios'
import gif from '../public/loading.gif'
import Image from 'next/image'
import Login from './Login'

const Register = () => {
    const [email, setemail] = useState("")
    const [password, setpassword] = useState("")
    const [loginemail, setloginemail] = useState()
    const [loginpassword, setloginpassword] = useState()
    const [confirmPass, setconfirmPass] = useState()
    const [state, setstate] = useState(true)
    const [message, setmessage] = useState("")
    const [loading, setloading] = useState(false)
    const [usersArr, setusersArr] = useState([])

    const register=()=>{
        
        if(!email || !password || !confirmPass) return setmessage("Fill all fields")
        let users = {email, password, confirmPass}
        setusersArr((prev)=>[...prev, users])
        if (password!==confirmPass) {
            setmessage("Confirm password must be same as password")
        }else{
            setloading(true)
            axios.post("http://localhost:4000/signup", users).then((res)=>{
                console.log(res);
                if(res.data.message && !res.data.status){
                    setmessage(res.data.message)
                }else{
                    Router.push('/Form')

                }
                    
                
                
                setloading(false)
            }).catch((err)=>{
                if(err){
                    setmessage(err.message)
                }else{
                    Router.push('/Form')
                }
            })
            console.log(usersArr);
          
            
        }
    }
    const login=()=>{
        if(!loginemail || !loginpassword) return setmessage("Fill all fields")
        let loginUser ={loginemail, loginpassword}
        setloading(true)
        axios.post("http://localhost:4000/login", loginUser).then((res)=>{
            console.log(res);
            if(res.data.message){
                setmessage(res.data.message)
                Router.push('/Form')
            }
            setloading(false)
        }).catch((err)=>{
            if(err){
                setmessage(err.message)
            }else{
                Router.push('/Form')
            }
        })
        setmessage("")

    }
  return (
    <>
      <div className="d-lg-flex container">
      {state==true ?<div className="shadow mt-5 p-5 col-lg-">
            <div className="row">
                <h1>Register now</h1>
                { message!== "" ?<b className='alert alert-danger'>{message}</b> : ""}
            <input className='form-control mb-3 p-3 shadow-sm border-0' onChange={(e)=>setemail(e.target.value)} value={email} placeholder='Example@gmail.com' type="text" />
            <input className='form-control mb-3 p-3 shadow-sm border-0' onChange={(e)=>setpassword(e.target.value)} value={password} placeholder='Password' type="text" />
            <input className='form-control mb-3 p-3 shadow-sm border-0' onChange={(e)=>setconfirmPass(e.target.value)} value={confirmPass} placeholder='Confirm password' type="text" />
            <button className='btn border-0' onClick={()=>setstate(!state)}>Login here</button>
            <button className='btn btn-primary' onClick={()=>register()}>Create cv</button>
            </div>
        </div> : 
          <div className="shadow mt-5 p-5 ">
          <div className="row">
              <h1>Welcome back</h1>
              { message!== "" ?<b className='alert alert-danger'>{message}</b> : ""}
          <input className='form-control mb-3 p-3 shadow-sm border-0' onChange={(e)=>setloginemail(e.target.value)} value={loginemail} placeholder='Example@gmail.com' type="text" />
          <input className='form-control mb-3 p-3 shadow-sm border-0' onChange={(e)=>setloginpassword(e.target.value)} value={loginpassword} placeholder='Password' type="text" />
          <button className='btn border-0' onClick={()=>setstate(!state)}>Create Account</button>
          <button className='btn btn-primary' onClick={()=>login()}>Login</button>
          </div>
      </div>
            }

        <div className='col-lg-6 mt-5 p-5' >
            <h2><b className='text-primary'>Dev CvCreator </b>is here for young and great developers looking for jobs, we are interested in helping you create a wonderful Curriculum vitae template to search for the job of your choice, Signup to create your CV</h2>
        </div>
      </div>
      {loading== true ? <div className='gif '>
      <Image  alt="" src={gif} width={1000} height={1000}/>
      </div> : ""}
    </>
  )
}

export default Register